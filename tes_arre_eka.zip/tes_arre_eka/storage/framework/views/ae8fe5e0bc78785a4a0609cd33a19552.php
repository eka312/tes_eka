

<?php $__env->startSection('judul_halaman', 'ubah Data Transaksi | Aplikasi DigiStore Manager'); ?>

<?php $__env->startSection('konten'); ?>
    <h1 class="mt-4">ubah data transaksi</h1>
    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">beranda</a></li>
            <li class="breadcrumb-item"><a href="/data_transaksi">data transaksi</a></li>
            <li class="breadcrumb-item active" aria-current="page">ubah data transaksi</li>
        </ol>
    </nav>

    <div class="card mb-4">
        <div class="card-header bg-primary text-light">
            <i class="fas fa-table me-1"></i>
            ubah daftar data transaksi
        </div>
        <div class="card-body text-capitalize">
            <form action="/ubah_transaksi/<?php echo e($transaksi->id_transaksi); ?>" method="post" >
                <?php echo csrf_field(); ?>
                <div class="mb-4 row">
                    <label class="col-sm-2 col-form-label">laptop</label>
                    <div class="col-sm-10">
                        <select name="id_laptop" value="<?php echo e($transaksi->nama_laptop); ?>" class="form-select" aria-label="Default select example">
                            <?php $__currentLoopData = $laptop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id_laptop); ?>"><?php echo e($item->nama_laptop); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="mb-4 row">
                    <label class="col-sm-2 col-form-label">pembeli</label>
                    <div class="col-sm-10">
                        <select name="id_pembeli" value="<?php echo e($transaksi->nama_pembeli); ?>" class="form-select" aria-label="Default select example">
                            <?php $__currentLoopData = $pembeli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id_pembeli); ?>"><?php echo e($item->nama_pembeli); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="mb-4 row">
                    <label for="text" class="col-sm-2 col-form-label">jumlah barang</label>
                    <div class="col-sm-10">
                        <input name="jumlah_barang" value="<?php echo e($transaksi->jumlah_barang); ?>"  class="form-control " type="number" placeholder="Masukkan jumlah barang" id="text" aria-label=".form-control-lg example">
                    </div>
                </div>
                <div class="mb-4 row">
                    <label for="text" class="col-sm-2 col-form-label">jumlah bayar</label>
                    <div class="col-sm-10">
                        <input name="bayar" value="<?php echo e($transaksi->bayar); ?>"   class="form-control " type="number" placeholder="Masukkan jumlah bayar" id="text" aria-label=".form-control-lg example">
                    </div>
                </div>
                <div class="mb-4 row">
                    <label for="text" class="col-sm-2 col-form-label">tanggal beli</label>
                    <div class="col-sm-10">
                        <input name="tggl_beli" value="<?php echo e($transaksi->tggl_beli); ?>" class="form-control " type="date"  id="text" aria-label=".form-control-lg example">
                    </div>
                </div>
                <div class="mb-4 row">
                    <label class="col-sm-2 col-form-label">penjual</label>
                    <div class="col-sm-10">
                        <select name="id_user" value="<?php echo e($transaksi->name); ?>" class="form-select" aria-label="Default select example">
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id_user); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templating.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eka\belajargit\tes_arre_eka\resources\views/transaksi/ubah_transaksi.blade.php ENDPATH**/ ?>