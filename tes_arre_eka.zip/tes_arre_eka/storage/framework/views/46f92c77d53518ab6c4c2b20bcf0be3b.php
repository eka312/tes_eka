

<?php $__env->startSection('judul_halaman', 'Data Laptop | Aplikasi DigiStore Manager'); ?>

<?php $__env->startSection('konten'); ?>
    <h1 class="mt-4">data laptop</h1>
    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">beranda</a></li>
            <li class="breadcrumb-item active" aria-current="page">data laptop</li>
        </ol>
    </nav>   
           
    <!-- bagian car dan tabel -->
    <div class="card mb-4">
        <div class="card-header bg-light">
            <div class="d-flex">
                <div class="flex-grow-1 d-flex align-items-center">
                    <i class="fas fa-table me-1"></i>
                    daftar data laptop
                </div>
                <div>
                    <a class="btn btn-primary btn-sm" href="/tambah_laptop" role="button"><i class="fas fa-add me-2"></i>Tambah</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>nama laptop</th>
                        <th>deskripsi</th>
                        <th>suplayer</th>
                        <th>stok</th>
                        <th>harga beli</th>
                        <th>harga jual</th>
                        <th>aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $laptop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($item->nama_laptop); ?></td>
                            <td><?php echo e($item->deskripsi); ?></td>
                            <td><?php echo e($item->nama_suplayer); ?></td>
                            <td><?php echo e($item->stok); ?></td>
                            <td><?php echo e($item->harga_beli); ?></td>
                            <td><?php echo e($item->harga_jual); ?></td>
                            <td>
                                <a class="btn btn-warning btn-sm mb-1" href="/ubah_laptop/<?php echo e($item->id_laptop); ?>" role="button"><i class="fas fa-edit me-2"></i>ubah</a>
                                <a class="btn btn-danger btn-sm" href="/hapus_laptop/<?php echo e($item->id_laptop); ?>" onclick="return confirm('apakah anda yakin ingin menghapus data ini?');" role="button"><i class="fas fa-trash me-2"></i>Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templating.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eka\belajargit\tes_arre_eka\resources\views/laptop/data_laptop.blade.php ENDPATH**/ ?>